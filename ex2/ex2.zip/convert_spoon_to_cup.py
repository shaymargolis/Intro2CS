#############################################################
# FILE : convert_spoon_to_cup.py
# WRITER : shay margolis , shaymar , 211831136
# EXERCISE : intro2cs1 ex2 2018-2019
# DESCRIPTION : Converts spoon units to cup units
#############################################################


def convert_spoon_to_cup(num_spoons):
    """ as 16 spoons are one cup, num_cups=num_spoons/16 """
    return num_spoons/16

